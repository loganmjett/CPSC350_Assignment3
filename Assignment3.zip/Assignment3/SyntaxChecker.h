#include "GenStack.h"
#include "Process.h"

using namespace std;

class SyntaxChecker
{
  public:

    //constructor
    SyntaxChecker(string f);

    //destructor
    ~SyntaxChecker();

    //helpers
    //does the brunt of the checking for syntax errors, returns true if correct, false if not
    bool isCorrect();
    //tests if a character is one of }, ], or )
    bool isEndContainerSyntax(char s);
    //tests if a character is one of {, [, or (
    bool isStartContainerSyntax(char s);
    //flips the given container syntax to its opposite
    char flip(char c);

    //pointer to the file process
    Process *output;
    //pointer a stack of chars
    GenStack<char> *cStack;


  private:
};
