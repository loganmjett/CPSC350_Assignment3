#include "SyntaxChecker.h"
#include <iostream>

using namespace std;

SyntaxChecker::SyntaxChecker(string f)
{
  output = new Process(f,"");
  cStack = new GenStack<char>();
}

SyntaxChecker::~SyntaxChecker()
{
  delete output;
  delete cStack;
}

bool SyntaxChecker::isEndContainerSyntax(char s)
{
  if (s == '}' || s == ']' || s == ')')
  {
    return true;
  }
  else
  {
    return false;
  }
}

bool SyntaxChecker::isStartContainerSyntax(char s)
{
  if (s == '{' || s == '[' || s == '(')
  {
    return true;
  }
  else
  {
    return false;
  }
}

char SyntaxChecker::flip(char c)
{
  if (isEndContainerSyntax(c))
  {
    if (c == '}')
    {
      return '{';
    }
    else if (c == '[')
    {
      return '[';
    }
    else
    {
      return '(';
    }
  }
  else
  {
    //if none of the above, this might be problematic
    return '\0';
  }
}

bool SyntaxChecker::isCorrect()
{
  bool correct;
  int errorLineNum = 1;
  string currLine;

  currLine = output->readLine();
  while (currLine != "")
  {
    for (char& i : currLine)
    {
      if (isStartContainerSyntax(i))
      {
        cStack->push(i);
      }
      else if (isEndContainerSyntax(i))
      {
        if (this->flip(i) == cStack->peek())
        {
          cStack->pop();
        }
        else
        {
          correct = false; //error found
          cout << "Error Found! Line: " << errorLineNum << endl;
          cout << "Details: Mismatch of syntax: " << i << endl;
          cout << "Please fix error and try again." << endl;
          break;
        }
      }
    }
    currLine = output->readLine();
    errorLineNum++;
  }
  if (correct)
  {
    if (cStack->isEmpty())
    {
      correct = true;
    }
    else
    {
      correct = false; //error found
      cout << "Reached end of file: Missing: " << this->flip(cStack->peek()) << endl;
    }
  }
  return correct;
}
