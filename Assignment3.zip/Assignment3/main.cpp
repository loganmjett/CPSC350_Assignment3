#include "SyntaxChecker.h"
#include <iostream>

using namespace std;

int main(int argc, char **argv) //was unsure how to get commandline filename to work
{

  SyntaxChecker *fileToCheck;
  string response; //response to continue or not
  string filename; //file provided by user

  cout << "Enter a file to check: " << endl;
  getline(cin, filename);

  fileToCheck = new SyntaxChecker(filename);


  while(!fileToCheck->isCorrect()) //loop continues until a file is incorrect, does not work proplerly
  {

    cout << "Would you like to continue with another file? Y for YES, N for NO." << endl;
    getline(cin, response);
    if (response == "Y" || response == "y")
    {
      cout << "Enter new file name: " << endl;
      getline(cin, filename);
      delete fileToCheck;
      fileToCheck = new SyntaxChecker(filename);
    }
    else
    {
      break;
    }
  }


  cout << "Thank you! Closing program..." << endl;

  delete fileToCheck; //deletes the instance of SyntaxChecker
  return 0;
}
